/**
 * 
 */
package administration;

import employees.Employee;
import employees.HourlyEmployee;
import employees.SalariedEmployee;
import employees.StudentEmployee;
/**
 * 
 */
public class PayrollReport {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// for testing various classes
		
		// class example but not in use for this
		//Employee e = new Employee("Elmer", "Fudd", 1);
		
		//System.out.println(e.toString());
		
		//HourlyEmployee he = new HourlyEmployee ("Name", "Name", 2, 160, 10.00);
		
		// Salaried employees
		Employee e1 = new SalariedEmployee("Doe", "John", 1, 75000);
        Employee e2 = new SalariedEmployee("Doe", "Jane", 2, 10000);
        
        // Hourly employees
        Employee e3 = new HourlyEmployee("Anderson", "Mike", 3, 120, 20.00);
        Employee e4 = new HourlyEmployee("Stevens", "Kayla", 4, 35, 15.00);
        
        // Student employees
        Employee e5 = new StudentEmployee("Roberts", "Bill", 5, 25, 14.50);
        Employee e6 = new StudentEmployee("Johnson", "Andy", 6, 40, 16.00);
		
		//System.out.println(he.toString());
		
        Employee[] employees = {e1, e2, e3, e4, e5, e6};
		
        System.out.println("***** Payroll Report *****");
        
        for (int i=0; i < employees.length; i++) {
			System.out.println(employees[i].toString());
			//System.out.println(employees[i].getMonthlyPay());
		}
			
		//declare totalPayroll to use outside the loop versus being local to just inside the loop.	
		double totalPayroll = 0.0; 
		for (int x = 0; x < employees.length; x++) {
			    totalPayroll += employees[x].getMonthlyPay();
			}
		
		
		//Couldn't figure out getting the spacing correct unfortunately.
		System.out.printf("Total Payroll: $%.2f\n", totalPayroll);
		// TODO Auto-generated method stub > eventually write the application code

	}

}
